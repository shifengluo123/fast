<template>
	<view class="container">
		<view class="page">
			<view class="item">
				<input class="iptName" type="text" v-model="phone" placeholder="请输入电话" />
			</view>
			<view class="loginBtn" @tap.stop="getIndex">
				进入
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				loginData:[],
				phone:''
			}
		},
		onLoad() {
			var that=this;
			if(that.globalData.phone){
				that.phone=that.globalData.phone
			}
			uni.showLoading({
				title: '加载中'
			});
			uni.request({
				url: that.globalData.siteUrl+ '/public/index.php/Index/index/milkOrderData',
				data: {
					
				},
				header: {
					'content-type': 'application/x-www-form-urlencoded',
				},
				
				method: 'POST',  
				
				success: function(res) {
					uni.hideLoading();
					that.loginData=res.data;
					console.log(that.loginData)
				},
				fail(res) {
					uni.hideLoading();
					uni.showToast({
						title: "网络异常，请求超时！",
						icon: 'none'
					})
				}
			})
		},
		methods: {
			getIndex(){
				var phone=this.phone;
				var loginData=this.loginData
				var that=this;
				if(phone!=''){
					var a=0;
					for (let i = 0; i < loginData.length; i++) {
						if(phone==loginData[i].parent_phone){
							a=1;
						}
					}
					if(a==1){
						that.globalData.phone=phone;
						uni.navigateTo({
							url:"../myOrder/myOrder"
						})
					}else{
						uni.showModal({
							title:'提示',
							content:'输入电话有错，或尚未下过单',
							showCancel:false,
						})
					}
				}else{
					uni.showToast({
						title:'电话不能为空',
						icon:'none'
					})
				}
			}
		}
	}
</script>

<style>
	.container{
		padding-top: 35vh;
	}
	.page{
		width: 60vw;
		height: 40vw;
		background-color: rgba(0,0,0,0.2);
		border-radius: 2vw;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
	.item{
		/* border: 1rpx solid ; */
		background-color: #FFFFFF;
		border-radius: 1vw;
		padding: 1.5vw;
	}
	.iptName{
		width: 38vw;
		height: 4vh;
	}
	.loginBtn{
		width: 40vw;
		padding: 3vw 0;
		text-align: center;
		background-color: #009688;
		color: #fff;
		font-size: 28rpx;
		border-radius: 2vw;
		margin-top: 3vh;
	}
</style>
