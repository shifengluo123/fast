<template>
	<view class="container">
		<view class="nothingData" v-if="orderData.length==0">
			<image src="../../static/img/nothing.png"></image>
			<text>暂无数据</text>
		</view>
		<view class="item" v-for="(item,index) in orderData" :key="index" v-else>
			<view class="itemData">
				<view class="item-left">
					<view>
						学生姓名：{{item.stu_name}}
					</view>
					<view>
						家长电话：{{item.parent_phone}}
					</view>
					<view>
						下单时间：{{item.create_time}}
					</view>
				</view>
				<view class="item-right">
					<view v-if="item.pay_state==0" @tap.stop='getPayment(item.id)'>未付款</view>
					<view v-else>已付款</view>
				</view>
			</view>
			<view>
				地址：{{item.region}}/{{item.school}}/{{item.grade}}/{{item.sclass}}
			</view>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				orderData:[],
			}
		},
		onLoad() {
			
			this.getMyMilkOrder();
		},
		onPullDownRefresh() {
			var that=this;
			this.getMyMilkOrder();
			setTimeout(function () {
				uni.stopPullDownRefresh();
			}, 1000);
		},
		methods: {
			getMyMilkOrder(){
				var that=this;
				console.log();
				uni.showLoading({
					title: '加载中'
				});
				uni.request({ //请求分类
					url: that.globalData.siteUrl + '/public/index.php/Index/index/myMilkOrder',
					data: {
						// phone:that.globalData.phone
						openid:that.globalData.openid
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded',
					},
					method: 'POST',
					success: function(res) {
						uni.hideLoading();//隐藏提示框
						console.log(res.data);
						if(res.data=='no'){
							
						}else{
							that.orderData=res.data;
						}
						console.log(that.orderData.length);
					},
					fail(res) {
						uni.hideLoading();
						uni.showToast({
							title: "网络异常，请求超时！",
							icon: 'none'
						})
					}
				})
			},
			getPayment:function(id){
				// console.log(id);
				var that=this;
				uni.showLoading({
					title: '加载中'
				});
				uni.request({ //请求分类
					url: that.globalData.siteUrl + '/public/index.php/Index/index/getPaymentOrderMilk',
					data: {
						id:id,
						openid:that.globalData.openid,
						back_url:that.globalData.siteUrl+"/public/index.php/Index/Wxpay/paysuccess_agent",
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded',
					},
					method: 'POST',
					success: function(res) {
						uni.hideLoading();//隐藏提示框
						console.log(res.data);
						var timestamp = Date.parse(new Date());
						timestamp = timestamp / 1000;
						uni.requestPayment({
						  'timeStamp': res.data["timeStamp"],
						  'nonceStr': res.data["nonceStr"],
						  'package': res.data["package"],
						  'signType': res.data["signType"],
						  'paySign': res.data["sign"],
						  'success': function (res) {
							console.log(res)
							if (res.errMsg == 'requestPayment:ok') {
						
							  uni.showToast({
							  	title: '支付成功',
								mask:true,
								icon:'none'
							  })
							}
						
						  },
						  fail(res) {
							console.log(res)
							uni.hideLoading();
							uni.showToast({
								title: '支付已取消',
								icon: 'none',
							})
						  },
						
						})
						// that.orderData=res.data;
					},
					fail(res) {
						uni.hideLoading();
						uni.showToast({
							title: "网络异常，请求超时！",
							icon: 'none'
						})
					}
				})
			},
		}
	}
</script>

<style>
	@import url("./myOrder.css");
</style>
