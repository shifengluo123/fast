<template>
	<view class="container">
		<rich-text class="rich" :nodes="agreementData.content"></rich-text>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				agreementData:[]
			}
		},
		onLoad() {
			var that=this;
			uni.showLoading({
				title: '加载中'
			});
			uni.request({ //请求分类
				url: that.globalData.siteUrl + '/public/index.php/Index/index/indexData',
				data: {
					
				},
				header: {
					'content-type': 'application/x-www-form-urlencoded',
				},
				method: 'POST',
				success: function(res) {
					uni.hideLoading();//隐藏提示框
					console.log(res.data)
					that.agreementData=res.data.agreementData;
				},
				fail(res) {
					uni.hideLoading();
					uni.showToast({
						title: "网络异常，请求超时！",
						icon: 'none'
					})
				}
			})
		},
		methods: {
			
		}
	}
</script>

<style>
	.rich{
		line-height: 5vh;
	}
</style>
