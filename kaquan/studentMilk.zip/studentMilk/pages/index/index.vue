<template>
	<view class="container">
		<view class="top">
			<image class="top-img" src="../../static/img/20200910152233.jpg"></image>
		</view>
		<!-- <view class="title">
			学生奶火热预定中~
		</view> -->
		<form @submit="subFromData">
			
			<view class="formData">
				<text class="itemTxt">学生信息</text>
				<view class="item">
					<picker mode="selector" @change="bindPickerChangeRegion" :range="regionList" range-key="name">
						<view class="item-right">
							<input class="pickIpt" disabled="true" name="region" :value="checkRegion" placeholder="请选择城市" />
							<image src="../../static/icon/down.png"  style="width: 3vw;height: 3vw;margin-left: 2vw;"></image>
						</view>
					</picker>
				</view>
				<view class="item">
					<picker mode="selector" @change="bindPickerChange" :range="school" range-key="name">	
						<view class="item-right">
							<input class="pickIpt" disabled="true" name="school" :value="checkSchool" placeholder="请选择学校" />
							<image src="../../static/icon/down.png"  style="width: 3vw;height: 3vw;margin-left: 2vw;"></image>
						</view>
					</picker>
				</view>
				<view class="item">
					<picker mode="selector" @change="bindGrade" :range="grade" range-key="name">
						<view class="item-right">
							<input class="pickIpt" disabled="true" name="grade" :value="checkGrade" placeholder="请选择年级" />
							<image src="../../static/icon/down.png"  style="width: 3vw;height: 3vw;margin-left: 2vw;"></image>
						</view>
					</picker>
				</view>
				<view class="item">
					<picker mode="selector" @change="bindClass" :range="sclass" range-key="name">
						<view class="item-right">
							<input class="pickIpt" disabled="true" name="sclass" :value="checkClass" placeholder="请选择班级" />
							<image src="../../static/icon/down.png"  style="width: 3vw;height: 3vw;margin-left: 2vw;"></image>
						</view>
					</picker>
				</view>
				<view class="item">
					<input class="itemIpt" name="stu_name" placeholder="请输入学生姓名" />
				</view>
			</view>
			
			<view class="formData">
				<text class="itemTxt">奶品信息</text>
				<view class="milkData">
					<view class="milk">
						蒙牛学生奶
					</view>
					<view class="milk">
						一学期 <text class="price">{{price}}</text>元
					</view>
				</view>
			</view>
			<view class="formData">
				<text class="itemTxt">家长信息</text>
				<view class="item">
					<input class="itemIpt" maxlength="11" type="number" name="parent_phone" placeholder="请输入电话" />
				</view>
			</view>
			<view class="item" @tap.stop="bindCheck">
				<label>
					<checkbox :checked="ischeck"></checkbox>
					<text class="itemTxt">已阅读</text>
					<text class="bule" @tap.stop="getAgreement">《{{indexData.title}}》</text>
					<text>同意征订</text>
				</label>
			</view>
			<button class="fromBtn" form-type="submit">提交报名</button>
		</form>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				school:[],
				checkSchool:'',
				grade:[],
				checkGrade:'',
				sclass:[],
				checkClass:'',
				ischeck:false,
				indexData:[],
				price:0,
				regionList:[],
				checkRegion:''
			}
		},
		onLoad() {
			var that=this;
			uni.login({
				success: (res) => {
					if(res.code){
						uni.request({
							url: that.globalData.siteUrl+ '/public/index.php/Index/index/OpenId',
							method: 'POST',
							header: { 'content-type': 'application/x-www-form-urlencoded' },
							data:{
								code:res.code
							},
							success:function(res){
								var data = res.data
								console.log(res);
								that.globalData.openid = data.resData.openid;
							}
						})
					}else{
						console.log('登录失败！' + res.errMsg)
					}
				}
			})
			that.getIndexData();
		},
		onShareAppMessage: function () {},
		methods: {
			bindPickerChangeRegion:function(e){
				var index=e.target.value;
				this.checkRegion=this.regionList[index].name;
			},
			getIndexData(){
				var that=this;
				uni.showLoading({
					title: '加载中'
				});
				uni.request({ //请求分类
					url: that.globalData.siteUrl + '/public/index.php/Index/index/indexData',
					data: {
						
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded',
					},
					method: 'POST',
					success: function(res) {
						uni.hideLoading();//隐藏提示框
						console.log(res)
						that.indexData=res.data.agreementData;
						var region=res.data.region;
						// console.log(region);
						that.regionList=res.data.region;
						that.school=res.data.school;
						that.grade=res.data.grade;
						that.sclass=res.data.sclass;
						that.price=res.data.price;
						console.log(that.school);
					},
					fail(res) {
						uni.hideLoading();
						uni.showToast({
							title: "网络异常，请求超时！",
							icon: 'none'
						})
					}
				})
				
			},
			getAgreement(){
				uni.navigateTo({
					url:'../agreement/agreement'
				})
			},
			bindCheck(){
				this.ischeck=!this.ischeck;
				console.log(this.ischeck);
			},
			bindPickerChange:function(e){
				var index=e.target.value;
				this.checkSchool=this.school[index].name;
			},
			bindGrade:function(e){
				var index=e.target.value;
				this.checkGrade=this.grade[index].name;
			},
			bindClass:function(e){
				var index=e.target.value;
				this.checkClass=this.sclass[index].name;
			},
			subFromData:function(e){
				var that=this;
				var data=e.detail.value;
				var str=/^1[3456789]\d{9}$/;
				if(data.school==''||data.grade==""||data.sclass==''||data.stu_name==''||!str.test(data.parent_phone)){
					uni.showToast({
						title:'必填项未填或格式不对',
						icon:'none'
					})
				}else{
					if(that.ischeck){
						uni.showLoading({
							title: '加载中'
						});
						uni.request({ //请求分类
							url: that.globalData.siteUrl + '/public/index.php/Index/index/subData',
							data: {
								money:that.price,
								region:data.region,
								school:data.school,
								grade:data.grade,
								sclass:data.sclass,
								stu_name:data.stu_name,
								parent_phone:data.parent_phone,
								pay_state:0,
								openid:that.globalData.openid,
								back_url:that.globalData.siteUrl+"/public/index.php/Index/Wxpay/paysuccess_agent",
							},
							header: {
								'content-type': 'application/x-www-form-urlencoded',
							},
							method: 'POST',
							success: function(res) {
								uni.hideLoading();//隐藏提示框
								console.log("res",res.data);
								var timestamp = Date.parse(new Date());
								timestamp = timestamp / 1000;
								uni.requestPayment({
								  'timeStamp': res.data["timeStamp"],
								  'nonceStr': res.data["nonceStr"],
								  'package': res.data["package"],
								  'signType': res.data["signType"],
								  'paySign': res.data["sign"],
								  'success': function (res) {
									console.log(res)
									if (res.errMsg == 'requestPayment:ok') {

									  uni.showToast({
									  	title: '支付成功',
										mask:true,
										icon:'none'
									  })
									}

								  },
								  fail(res) {
									console.log(res)
									uni.hideLoading();
									uni.showToast({
										title: '支付已取消',
										icon: 'none',
									})
								  },

								})
								
							},
							fail(res) {
								uni.hideLoading();
								uni.showToast({
									title: "网络异常，请求超时！",
									icon: 'none'
								})
							}
						})
					}else{
						uni.showModal({
							title:'提示',
							content:'是否确定已阅读相关协议！',
							success(res) {
								if(res.confirm){
									that.ischeck=true;
								}
							}
						})
					}
				}
				
			},
		}
	}
</script>

<style>
	@import url("./index.css");
</style>
