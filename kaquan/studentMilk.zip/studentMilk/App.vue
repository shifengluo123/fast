<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/*每个页面公共css */
	page{
		background-color: #f7f7f7;
		font-size: 28rpx;
	}
	.container{
		width: 94vw;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		padding: 2vw 3vw;
	}
</style>
